MQTT_SERVER = "a8da53fe3a6e4a88a680cec95e21b82e.s1.eu.hivemq.cloud"
MQTT_PORT = 8883
MQTT_USER = "jonathan"
MQTT_PASSWORD = "Senha123"
